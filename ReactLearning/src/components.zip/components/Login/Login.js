import React from 'react';
import './Login.css'

const LoginModal = (props) => {
    return(
        <div className="modalcontainer">
            <div class="modalwrapper">
                <div class="wrapperdiv">
                    <span>Username : </span>
                    <input type= "text" name="inputUsername" onChange={props.onInputChange}></input>
                </div>
                <div class="wrapperdiv">
                    <span>Password : </span>
                    <input type= "text" name="inputPassword" onChange={props.onInputChange}></input>
                </div>
                <button class="loginbtn" onClick={props.onButtonClick}>LOGIN</button>
            </div>
        </div>
    )
}

export default LoginModal; 