import React from 'react';

const ToastMessage = (props) => {
    console.log("props==== ",props);
    return(
        <div>
            <h1 class="toastposition">{props.message}</h1>
        </div>
    )
}

export default ToastMessage;